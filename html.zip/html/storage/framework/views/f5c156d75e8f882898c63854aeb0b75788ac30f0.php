<?php /* /var/www/html/resources/views/orders/multipleSubscriptionsResume.blade.php */ ?>
<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Resume Subscription</title>
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
         <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
        <script>
            let subscriptions = [];
            let optiona = [];
            let optionb = [];

        </script>
    </head>
    <body>
    <div class="container">
        <form method="POST" action="/resumeSubscription">
            <?php echo csrf_field(); ?>
            <div class="col-12 text-center">
                <img src="https://cdn2.hubspot.net/hubfs/5353367/Vitally_June2019%20/Images/logo-pink_673945c4-7029-41f1-937d-949c32aa98e4_100x.png">
            </div>
            <div class="col-12">
                <h2>Resume Subscription</h2>
            </div>
            <div class="col-12">
                <p>You have multiple paused subscriptions. Please select subscription to resume.</p>
            </div>
            <div class="col-12">
                <input type="hidden" name="shopifyId" value="<?php echo $subscriptions[0]['shopify_customer_id'];?>" />
                <select name="subscriptionID" id="subscriptionId"  required onchange="updateDates()">
                    <option value="" selected>Select</option>
                <?php
                //print_r($subscriptions);
                $options = array();
                foreach ($subscriptions as $subscription){
                    $tarr = array();
                    $att = json_decode($subscription['attributes'],true);
                    $tarr['nameonpack'] = $att['name-on-pack'];
                    echo "<option value='" . $subscription['id'] . "'>" . $att['name-on-pack'] . "'s Pack</option>";
                    echo "<script>subscriptions.push('" . $subscription['id'] . "');</script>";
                    $tarr['subscriptionId'] = $subscription['id'];
                    $tarr['customerId'] = $subscription['shopify_customer_id'];
                    $tarr['lastShip'] = $subscription['last_ship_date'];
                    $tarr['nextShip'] = $subscription['next_active_ship_date'];
                    $today = new DateTime();
                    $nextShip = new DateTime($subscription['next_active_ship_date']);
                    $dDiff = $today->diff($nextShip);
                    $diff = $dDiff->d;
                    $inThreeDays = new DateTime();
                    $inThreeDays->add(new DateInterval('P3D'));
                    if($diff < 3){
                        $tarr['option1'] = $subscription['next_active_ship_date'];
                        $tarr['option2'] = $nextShip->add(new DateInterval('P7D'))->format('Y-m-d');
                        if(strtotime($tarr['option1']) > strtotime($tarr['option2'])){
                            $td = $tarr['option2'];
                            $tarr['option2'] = $tarr['option1'];
                            $tarr['option1'] = $td;
                        }
                        echo "<script>optiona.push('" . $tarr['option1'] . "');</script>";
                        echo "<script>optionb.push('" . $tarr['option2'] . "');</script>";
                    } else {
                        $tarr['option1'] = $inThreeDays->format('Y-m-d');
                        $tarr['option2'] = $subscription['next_active_ship_date'];
                        if(strtotime($tarr['option1']) > strtotime($tarr['option2'])){
                            $td = $tarr['option2'];
                            $tarr['option2'] = $tarr['option1'];
                            $tarr['option1'] = $td;
                        }
                        echo "<script>optiona.push('" . $tarr['option1'] . "');</script>";
                        echo "<script>optionb.push('" . $tarr['option2'] . "');</script>";
                    }
                }
                ?>
                </select>
            </div>
            <div class="col-12">&nbsp;</div>
            <div class="col-12">
                Please select next delivery date
            </div>
            <div class="col-12">
                <select name="delDate" id="delDate" required>
                    <option value="">Select</option>
                </select>
            </div>
            <div class="col-12">&nbsp;</div>
            <div class="col-12">
                <button type="submit" class="btn btn-success">Resume Subscription</button>
            </div>
        </form>
    </div>


    <script>
            function updateDates(){
                let subsc = $('#subscriptionId').val();
                console.log(subsc);
                let selIndex = $("#subscriptionId").prop('selectedIndex');
                selIndex--;
                let opA = optiona[selIndex];
                let opB = optionb[selIndex];
                $('#delDate').find('option').remove().end();
                $('#delDate').append('<option value="" selected="selected">Select</option>');
                $('#delDate').append('<option value="' + opA + '">' + opA + '</option>');
                $('#delDate').append('<option value="' + opB + '">' + opB + '</option>');
            }
    </script>
    </body>
</html>