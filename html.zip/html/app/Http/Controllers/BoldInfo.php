<?php

namespace App\Http\Controllers;

Use Illuminate\Http\Request;
Use Illuminate\Support\Facades\Log;
Use GuzzleHttp\Client;
use DateTime;

class BoldInfo extends Controller
{

    CONST apiKey = '8333e491-3830-42e6-ac82-3129b80fca36';
    CONST portalID = '5353367';
    CONST formID = '5ddcd825-f9ba-4426-99f4-f1e7c4920ea8';
    CONST huburl = 'https://api.hubapi.com/properties/v1/contacts/properties?hapikey=' . Self::apiKey;


    /*  Products in subscription
        Value of subscription
        Paused or active
        Next order date(s)
        Are those orders skipped
    */
    public function newOrder(Request $request){
        $secret = '6d01ff9ea5cff9b17c03ed0616c50a3de1cc0c5f58f183443d5fb44acbbb64ea';
        $webhook_content = NULL;
        $webhook = fopen('php://input' , 'rb');
        while (!feof($webhook)) {
            $webhook_content .= fread($webhook, 4096);
        }
        fclose($webhook);
        $webhook_content = json_decode($webhook_content, TRUE);
        Log::critical("New ORDER ----->");
        Log::critical($webhook_content);
        $form_params = array();
        $order_value = $webhook_content['data']['order']['total'];
        $order_date = $webhook_content['data']['order']['transaction_date'];
        $order_interval = $webhook_content['data']['subscription']['interval_number'];
        //$next_date = date('Y-m-d', strtotime($order_date . " +$order_interval days"));
        $next_date = $webhook_content['data']['subscription']['next_active_ship_date'];
        $shopify_customer_id = $webhook_content['data']['subscription']['shopify_customer_id'];
        $form_params['email'] = $webhook_content['data']['subscription']['customer_email'];
        $form_params['bold_currency'] = $webhook_content['data']['subscription']['currency'];;
        $form_params['bold_value'] = $order_value;
        $form_params['bold_last_order_date'] = $order_date;
        $form_params['bold_next_order_date'] = $next_date;
        $form_params['bold_status'] = "Active";
        $form_params['shopify_id'] = $shopify_customer_id;
        $this->pushhubspot($form_params);
    }

    public function pushhubspot($formparams){
        //$formparams['bold_json_string'] = json_encode($formparams);
        $client = new Client();
        $response = $client->post('https://forms.hubspot.com/uploads/form/v2/' . Self::portalID . '/' . Self::formID, [
            'form_params' => $formparams,
        ]);
        Log::critical(json_encode($formparams));
    }

    public function hubspotcreateorupdate($properties, $email){
        $url = "https://api.hubapi.com/contacts/v1/contact/createOrUpdate/email/" . $email . "/?hapikey=" . Self::apiKey;
        $client = new Client();
        $request = $client->request('POST', $url,  ['body'=>json_encode($properties)]);
        $response = $request->getStatusCode();
        Log::critical($response);
    }

    public function subscriptioncancel(Request $request){
        $webhook_content = NULL;
        $webhook = fopen('php://input' , 'rb');
        while (!feof($webhook)) {
            $webhook_content .= fread($webhook, 4096);
        }
        fclose($webhook);
        $webhook_content = json_decode($webhook_content, TRUE);
        Log::critical("Subscription Cancellation ---->>>");
        Log::critical($webhook_content);
        $shopify_customer_id = $webhook_content['data']['subscription']['shopify_customer_id'];
        $properties['properties'] = array();
        $tarr = array();
        $tarr['property'] = 'shopify_id';
        $tarr['value'] = $shopify_customer_id;
        $properties['properties'][] = $tarr;
        $tarr = array();
        $tarr['property'] = 'bold_status';
        $tarr['value'] = "Cancelled";
        $properties['properties'][] = $tarr;
        $tarr = array();
        $tarr['property'] = 'bold_order_pause_date';
        $tarr['value'] = strtotime('today midnight') * 1000;
        $properties['properties'][] = $tarr;
        $this->hubspotcreateorupdate($properties, $webhook_content['data']['subscription']['customer_email']);
    }

    public function subscriptionrestart(Request $request){
        $webhook_content = NULL;
        $webhook = fopen('php://input' , 'rb');
        while (!feof($webhook)) {
            $webhook_content .= fread($webhook, 4096);
        }
        fclose($webhook);
        $webhook_content = json_decode($webhook_content, TRUE);
        Log::critical("Subscription Reactivated --->>>");
        Log::critical($webhook_content);
        $properties['properties'] = array();
        $shopify_customer_id = $webhook_content['data']['subscription']['shopify_customer_id'];
        $tarr = array();
        $tarr['property'] = 'shopify_id';
        $tarr['value'] = $shopify_customer_id;
        $properties['properties'][] = $tarr;
        $tarr = array();
        $tarr['property'] = 'bold_last_order_date';
        $tarr['value'] = strtotime($webhook_content['data']['subscription']['last_ship_date']) * 1000;
        $properties['properties'][] = $tarr;
        $tarr = array();
        $tarr['property'] = 'bold_next_order_date';
        $tarr['value'] = strtotime($webhook_content['data']['subscription']['next_ship_date']) * 1000;
        $properties['properties'][] = $tarr;
        $tarr = array();
        $tarr['property'] = 'bold_status';
        $tarr['value'] = "Active";
        $properties['properties'][] = $tarr;
        $tarr = array();
        $tarr['property'] = 'bold_order_pause_date';
        $tarr['value'] = "";
        $properties['properties'][] = $tarr;
        $this->hubspotcreateorupdate($properties, $webhook_content['data']['subscription']['customer_email']);
    }

    public function orderpause(Request $request){
        $webhook_content = NULL;
        $webhook = fopen('php://input' , 'rb');
        while (!feof($webhook)) {
            $webhook_content .= fread($webhook, 4096);
        }
        fclose($webhook);
        $webhook_content = json_decode($webhook_content, TRUE);
        Log::critical("Subscription Pause --->>>");
        Log::critical($webhook_content);
        $properties['properties'] = array();
        $shopify_customer_id = $webhook_content['data']['subscription']['shopify_customer_id'];
        $tarr = array();
        $tarr['property'] = 'shopify_id';
        $tarr['value'] = $shopify_customer_id;
        $properties['properties'][] = $tarr;
        $tarr = array();
        $tarr['property'] = 'bold_last_order_date';
        $tarr['value'] = strtotime($webhook_content['data']['subscription']['last_ship_date']) * 1000;
        $properties['properties'][] = $tarr;
        $tarr = array();
        $tarr['property'] = 'bold_next_order_date';
        $tarr['value'] = strtotime($webhook_content['data']['subscription']['next_ship_date']) * 1000;
        $properties['properties'][] = $tarr;
        $tarr = array();
        $tarr['property'] = 'bold_order_pause_date';
        $tarr['value'] = strtotime('today midnight') * 1000;
        $properties['properties'][] = $tarr;
        $tarr = array();
        $tarr['property'] = 'bold_status';
        $tarr['value'] = 'Inactive';
        $properties['properties'][] = $tarr;
        $this->hubspotcreateorupdate($properties, $webhook_content['data']['subscription']['customer_email']);
    }

//
//    public function orderresume(Request $request){
//        $webhook_content = NULL;
//        $webhook = fopen('php://input' , 'rb');
//        while (!feof($webhook)) {
//            $webhook_content .= fread($webhook, 4096);
//        }
//        fclose($webhook);
//        $webhook_content = json_decode($webhook_content, TRUE);
//        Log::critical("Subscription Resume --->>>");
//        Log::critical($webhook_content);
//        $shopify_customer_id = $webhook_content['data']['subscription']['shopify_customer_id'];
////        $form_params['bold_last_order_date'] = $webhook_content['data']['subscription']['last_ship_date'];
////        $form_params['bold_next_order_date'] = $webhook_content['data']['subscription']['next_ship_date'];
//        $form_params['bold_status'] = "Active";
//        $form_params['bold_order_pause_date'] = '';
//        $form_params['shopify_id'] = $shopify_customer_id;
//        $this->hubspotcreateorupdate($form_params, $webhook_content['data']['subscription']['customer_email']);
//    }
}