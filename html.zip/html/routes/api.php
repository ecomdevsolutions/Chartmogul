<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});
/* Webhooks */
Route::post('/neworder', 'BoldInfo@newOrder');
Route::post('/subscriptioncancel', 'BoldInfo@subscriptioncancel');
Route::post('/subscriptionrestart', 'BoldInfo@subscriptionrestart');
Route::post('/orderpause', 'BoldInfo@orderpause');
Route::post('/orderresume', 'BoldInfo@subscriptionrestart');

/* API URLS */
Route::post('/initiate', 'ThirdpParty@initiate');
Route::post('/productInfo', 'ThirdpParty@productInfo');
Route::post('/updateQty', 'ThirdpParty@updateQty');
Route::get('/getShippingRates', 'ThirdpParty@getShippingRates');
Route::get('/getShipping', 'ThirdpParty@getShipping');
Route::post('/updateAddress', 'ThirdpParty@updateAddress');


